// 2 toog nemeh vildel 
 //  function ilerhiilel
// const add = (value1,value2) =>{
//     const result = value1 + value2;
//     document.write(result + "<br>");
// }
// add(5,10);
// add(100,300);
//             // function zarlalt
// function max (value1,value2){
//     if(value1>value2){
//         // utga butsaanaa
//         return value1;
//     }
//     else{
//     return value2
//     }
// }
// console.log(max(100,800)); // garalt n  deer 800
// //   suman function
// let calculateisOn = true;
// const pressPowerButton = () => {
//     if(calculateisOn){
//         console.log('toonii mashin assan baina');
//         calculateisOn = false;
//     }
//     else{
//         console.log('toonii mashin untarsan baina');
//     }
// }
// pressPowerButton();
// pressPowerButton();


const square = function(number) {
    return Math.sqrt(number);
    //  return number * number 
    }
var x = square(16) // x gets the value 16
console.log(x);


// ternary operation

// let balance = 10000;
// balance > 5000?console.log('Гүйлгээ хийх эрхтэй'):console.log('Үлдэгдэл хүрэлцэхгүй байна');

// if(balance>5000){
//     console.log('Гүйлгээ хийх эрхтэй');
// }
// else{
//     console.log('үлдэгдэл хүрэлцэхгүй байна');
// }