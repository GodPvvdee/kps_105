// var counter;
// for (counter = 1; counter <= 10; counter++)
// {
// document.write(counter*counter + ":");
// }

                // for loop example
                
// let states = ['dallas','boston','denver'];
// for(let i = states.length-1; i>=0; i--){
//     console.log(states[i]);
// }    
                    // double for loop example

// let bookcase1 = ['Харри Поттер','Самар хатан'];
// let bookcase2 = ['Bad blood','Харри Поттер'];
// for(let i =0 ; i<bookcase1.length; i++){
//     for(let j=0; j<bookcase2.length;j++){
//         if(bookcase1[i] === bookcase2[j]){
//         console.log('Давхардсан ном: ' + bookcase1[i]);
//     }
//     }
// }

                        // IF ELSE  
// let trafficLight = 'ногоон';

// if(trafficLight === 'улаан'){
//     console.log('зогс');
// }
// else if(trafficLight === 'ногоон'){
//     console.log('явна');
// }
// else{
//     console.log('болгоомжил. гэрлэн дохио ажиллахгүй');
// }

// let age=20;
// if(age>=21){
// console.log("Та пиво ууж болно")
// }
// else{ 
// console.log("Агаан дүү гэртэй бай!!!")
// }
                // for in loop
//  var book="mongol";  
// var booklist = new Array("Chinese", "English", "Jap");
// for (var counter in booklist) {
// 	book +=   booklist[counter] +  " - ";
// }
// alert( book);

                        // while
//  let words  = 'Улаанбаатар хот, Монгол улс';
//  let i =0;
//  while('' !== words[i]){
//      i++;
//  }
//  console.log('Эхний үгийн урт:' + i);
                               
var counter = 100;
var numberlist = "";
while (counter > 0) {
numberlist += "Number " + counter + "<br>";
counter -= 10;
}
document.write(numberlist);  
// while(false) {
//     console.log('hack!!!');
// }